"""
Конфигурация проекта и настройка API Mistral.
"""

import os

# API ключ Mistral - установите ваш ключ здесь или через переменную окружения
MISTRAL_API_KEY = os.getenv("MISTRAL_API_KEY", "q79I2kkg48trmbqzqaQ4WOwNeyUgMx0U")

# Настройки модели
MISTRAL_MODEL = "mistral-medium"  # или "mistral-small", "mistral-large"
MISTRAL_BASE_URL = "https://api.mistral.ai/v1"

# Настройки запросов
DEFAULT_TEMPERATURE = 0.7
DEFAULT_MAX_TOKENS = 2000
DEFAULT_TIMEOUT = 30  # секунд

# Настройки логирования
LOG_LEVEL = "INFO"
LOG_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"

def validate_config():
    """Проверка конфигурации."""
    if not MISTRAL_API_KEY:
        raise ValueError(
            "Не указан API ключ Mistral. "
            "Установите его в config.py или через переменную окружения MISTRAL_API_KEY"
        )
    
    return {
        "api_key": MISTRAL_API_KEY,
        "model": MISTRAL_MODEL,
        "base_url": MISTRAL_BASE_URL,
        "temperature": DEFAULT_TEMPERATURE,
        "max_tokens": DEFAULT_MAX_TOKENS,
        "timeout": DEFAULT_TIMEOUT
    }
